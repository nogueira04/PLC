splitOn :: Char -> String -> [String]
splitOn _ [] = [""]
splitOn delim (c:cs)
    | c == delim = "" : rest
    | otherwise = (c : head rest) : tail rest
  where
    rest = splitOn delim cs

extractValues :: String -> [Double]
extractValues s = map readDouble values
  where
    parts = splitOn ';' s

    values = filter isCompra (drop 2 parts)

    isCompra :: String -> Bool
    isCompra val = case reads val :: [(Double, String)] of
        [(_, "")] -> True
        _ -> False
    
    readDouble :: String -> Double
    readDouble str = case reads str of
        [(val, "")] -> val
        _ -> 0.0

minMaxCartao :: String -> (Double, Double)
minMaxCartao s = (minimum values, maximum values)
  where
    values = extractValues s

    
main = do
    a <- getLine
    let result = minMaxCartao a
    print result
