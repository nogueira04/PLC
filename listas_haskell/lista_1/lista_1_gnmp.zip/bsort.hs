bSort :: [String] -> [String]
bSort [] = []
bSort xs = bubble xs (length xs)
  where
    bubble xs 0 = xs
    bubble xs n = bubble (pass xs) (n - 1)
    pass [x] = [x]
    pass (x:y:xs)
      | x > y     = y : pass (x:xs)
      | otherwise = x : pass (y:xs)

main = do
    a <- getLine
    let result = bSort (read a :: [String])
    print result